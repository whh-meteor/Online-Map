<template>
  <div id="cesiumContainer"></div>
</template>

<script>
/* eslint-disable */
import "../../public/Cesium/Widgets/widgets.css";
export default {
  name: "OnlineMap",
  props: {
    msg: String,
  },
  data() {
    return {
      viewer: null,
    };
  },
  methods: {
    initCesium() {
      this.viewer = new Cesium.Viewer("cesiumContainer");
    },
  },
  mounted() {
    this.initCesium();
  },
};
</script>
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
